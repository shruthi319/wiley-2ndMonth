import java.util.Arrays;
import java.util.Scanner;

public class MinAbsSum {
	static void minabsSum(int arr[]) {
		Arrays.sort(arr);
		if(arr.length<2) 
			return ;
		int low=0;
		int i=0,j=0;
		int high=arr.length-1;
		int min=Integer.MAX_VALUE;
		while(low<high) {
			if(Math.abs(arr[low]+arr[high])<min)
			{
				min=Math.abs(arr[low]+arr[high]);
				i=low;
				j=high;
			}
			if(min==0)
				break;
			if(arr[low]+arr[high]<0)
				low++;
			else
				high--;
		}
		System.out.println(min+" is the minimum absolute sun of "+arr[i]+" "+arr[j]);
		
	}
 public static void main(String args[]) {
	 int arr[]= {3,5,-6,-2,88,34,-26,-3,2};
	 minabsSum(arr);
	
 }
}
