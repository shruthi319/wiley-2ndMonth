

public class BinaryNode {
	    int data;
		BinaryNode left;
		BinaryNode right;
		BinaryNode(int data){
			this.data=data;
			left=right=null;
		}
	}

