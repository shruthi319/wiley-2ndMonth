import java.util.Arrays;

/*Given weights and values of n items, put these items in a knapsack of capacity W to get the maximum total value in the knapsack. 
 * In other words, given two integer arrays val[0..n-1] and wt[0..n-1] which represent values and weights associated with n items respectively. 
 * Also given an integer W which represents knapsack capacity, find out the maximum value subset of val[] such that sum of the weights of this subset is smaller than or equal to W.
 *  You cannot break an item, either pick the complete item or don�t pick it (0-1 property).*/

/*Recursion by Brute-Force algorithm OR Exhaustive Search.
Approach: A simple solution is to consider all subsets of items and calculate the total weight and value of all subsets. Consider the only subsets whose total weight is smaller than W. From all such subsets, pick the maximum value subset.
Optimal Sub-structure: To consider all subsets of items, there can be two cases for every item. 

Case 1: The item is included in the optimal subset.
Case 2: The item is not included in the optimal set.
Therefore, the maximum value that can be obtained from �n� items is the max of the following two values. 

Maximum value obtained by n-1 items and W weight (excluding nth item).
Value of nth item plus maximum value obtained by n-1 items and W minus the weight of the nth item (including nth item).
If the weight of �nth� item is greater than �W�, then the nth item cannot be included and Case 1 is the only possibility.*/



public class KnapSack01 {
	static int dp[][];
	static int knapsack(int W,int wt[],int val[],int n)
	{
		// Base Case
		if(W==0 || n==0) {
			return 0;
		}
		// If weight of the nth item is
        // more than Knapsack capacity W,
        // then this item cannot be included
        // in the optimal solution
		if(wt[n-1]>W) {
			return knapsack(W,wt,val,n-1);
		}
		else {
			 // Return the maximum of two cases:
	        // (1) nth item included
	        // (2) not included
			return Math.max(val[n-1]+knapsack(W-wt[n-1],wt,val,n-1),knapsack(W,wt,val,n-1));
		}	
	}
	static int knapsack1(int W,int wt[],int val[],int n)
	{
		// Base Case
		if(W==0 || n==0) {
			return 0;
		}
		// If weight of the nth item is
        // more than Knapsack capacity W,
        // then this item cannot be included
        // in the optimal solution
		if(wt[n-1]>W) {
			return knapsack(W,wt,val,n-1);
		}
		if(dp[n-1][n-1]!=0)
			return dp[n-1][n-1];
		else {
			 // Return the maximum of two cases:
	        // (1) nth item included
	        // (2) not included
			int incl=val[n-1]+knapsack(W-wt[n-1],wt,val,n-1);
			int excl=knapsack(W,wt,val,n-1);
			dp[n-1][n-1]=Math.max(incl,excl);
			return Math.max(incl,excl);
		}	
	}
	static int KS_Calc(int W, int wt[],int val[], int n)
	{
		int i, w;
		int K[][] = new int[n + 1][W + 1];

		// Build table K[][] in bottom up manner
		for (i = 0; i <= n; i++)
		{
			for (w = 0; w <= W; w++)
			{
				if (i == 0 || w == 0)
					K[i][w] = 0;
				else if (wt[i - 1] <= w)
					K[i][w]= Math.max(val[i - 1]
							+ K[i - 1][w - wt[i - 1]],
							K[i - 1][w]);
				else
					K[i][w] = K[i - 1][w];
			}
		}
		return K[n][W];
	}
	
	public static void main(String[] args) {
		/*int val[] = new int[] { 60, 100, 120 };
        int wt[] = new int[] { 10, 20, 30 };
        int W = 50;
        int n = val.length;*/
        //System.out.println(knapsack(W, wt, val, n));
        int val[] = new int[] { 60, 100, 120,100,250,30,90,200 };
		int wt[] = new int[] { 10, 20, 30,40,35,20,66,100 };
		int W = 500;
		int n = val.length;
        dp=new int[n+1][n+1];
        for(int row[]:dp) {
        	Arrays.fill(row,0);
        }
        //both knapsack1 and KS_Calc would return same ans , both use dp
        //System.out.println(knapsack1(W, wt, val, n));
        System.out.println(KS_Calc(W, wt, val, n));
	}
}
