import java.util.HashMap;

public class MaxNonAdjacentSum {
	static HashMap<BinaryNode,Integer> dp;
	public static void main(String args[]) {
		BinaryTree bt=new BinaryTree();
		bt.root=new BinaryNode(1);
		bt.root.left= new BinaryNode(2);
        bt.root.right = new BinaryNode(3);
        bt.root.left.left= new BinaryNode(9);
        bt.root.left.right= new BinaryNode(3);
        bt.root.right.left = new BinaryNode(4);
        bt.root.right.right = new BinaryNode(3);
        bt.root.left.right.right= new BinaryNode(5);
        bt.root.left.right.left= new BinaryNode(88);
        bt.root.left.left.left =  new BinaryNode(44);
        bt.root.left.left.right = new BinaryNode(66);
        /*bt.root.left.left.right.left = new BinaryNode(100);
        bt.root.left.left.right.right = new BinaryNode(105);
        bt.root.right.left.left.left = new BinaryNode(12);
        bt.root.right.left.left.right = new BinaryNode(13);
        bt.root.right.left.right.left = new BinaryNode(255);
        bt.root.right.left.right.right = new BinaryNode(28);*/

        //System.out.println(maxNonAdjSum(bt.root));
        //System.out.println(maxNonAdjSum1(bt.root));
        dp=new HashMap<>();
        System.out.println(findsum2(bt.root));

	}
	
	static int maxNonAdjSum(BinaryNode root){
		if(root==null)
			return 0;
		if(root.left==null && root.right==null)
			return root.data;
		int exclsum=root.left.data+root.right.data;
		int inclsum=root.data+maxNonAdjSum(root.left.left)+
							maxNonAdjSum(root.left.right)+
							maxNonAdjSum(root.right.left)+
							maxNonAdjSum(root.right.right);
		System.out.println(Math.max(inclsum, exclsum));
		return Math.max(inclsum, exclsum);	
	}
	static int maxNonAdjSum1(BinaryNode root){
		if(root==null)
			return 0;
		int incl=root.data;
		if(root.left!=null) {
			incl+=maxNonAdjSum1(root.left.left);
			incl+=maxNonAdjSum1(root.left.right);
		}
		if(root.right!=null) {
			incl+=maxNonAdjSum1(root.right.left);
			incl+=maxNonAdjSum1(root.right.right);
		}
		int excl=maxNonAdjSum1(root.left)+maxNonAdjSum(root.right);
		return Math.max(incl, excl);
	}
	static int findsum2(BinaryNode root) {
		if(root==null)
			return 0;
		if(dp.containsKey(root)) {
			return dp.get(root);
		}
		int incl=root.data;
		if(root.left!=null) {
			incl+=maxNonAdjSum1(root.left.left);
			incl+=maxNonAdjSum1(root.left.right);
		}
		if(root.right!=null) {
			incl+=maxNonAdjSum1(root.right.left);
			incl+=maxNonAdjSum1(root.right.right);
		}
		int excl=maxNonAdjSum1(root.left)+maxNonAdjSum(root.right);
		dp.put(root,Math.max(incl, excl));
		return dp.get(root);
	}
}

