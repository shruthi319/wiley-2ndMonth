import java.util.Scanner;
public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a=0,b=1;
		int c;
		int arr[]=new int[n];
		arr[0]=0;
		arr[1]=1;
		for(int i=2;i<n;i++) {
			c=a+b;
			arr[i]=c;
			a=b;
			b=c;
		}
		for(int i=0;i<n;i++) {
			System.out.print(arr[i]+"->");
		}
		System.out.println();
		System.out.println("Enter which term u want in series");
		int te=sc.nextInt();
		System.out.println(arr[te-1]);
	}

}
