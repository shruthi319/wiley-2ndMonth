import java.util.Scanner;
public class DiffInBits {
	static String convertToBits(int num){
		StringBuffer sb=new StringBuffer(); 
	     int index = 0;    
	     while(num > 0){    
	       sb.append((int) (num%2));    
	       num = num/2;    
	     }    
	     while(sb.length()<=4) {
	    	 sb.append(0);
	     }
	     sb=sb.reverse();
	     System.out.println(sb);
	     return sb.toString();
	}
	static int findDiff(int one,int two) {
		String one1=convertToBits(one);
		//System.out.println(one1);
		String two1=convertToBits(two);
		//System.out.println(one1);
		int count=0;
		for(int i=0;i<one1.length();i++) {
			if(one1.charAt(i)!=two1.charAt(i))
			{
				count++;
			}
		}
		return count;	
	}

	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int one=3;
		int two=3;
		//findDiff(one,two);
		System.out.println(findDiff(one,two));
	}
}
