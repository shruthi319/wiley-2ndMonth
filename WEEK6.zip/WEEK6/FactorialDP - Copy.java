import java.util.Scanner;
public class FactorialDP {
	
	static int fact[];
	static int factorial(int n) {
		if(n<=2)
			return n;
		if(fact[n]!=0)
			return fact[n];
		fact[n]=n*factorial(n-1);
		return fact[n];
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		fact=new int[n+1];
		int ans=factorial(n);
		System.out.println(ans);
	}
}
/*
 * fact(7) =7*fact(6);
 * fact(6)=6*fact(5);//ie we are using fact(6) for fact(7),fact(6) requires fact(5) , but if we stores calculated values of fact(5), fact(6) they will be useful in every next calculation
 */
