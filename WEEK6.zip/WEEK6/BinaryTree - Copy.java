
public class BinaryTree {
	BinaryNode root;
	public BinaryTree(){
		root=null;
	}	
}
