import java.util.Arrays;
import java.util.Scanner;
public class CountMatrixOpr {
	static long  DP[][];
	//this is the recursive approach and checks for all the possible combinations and get the combination which would take minimum operations for combining the matrices
	static long minMatrixCalc1(int p[],int i,int j) {
		if(i==j) {
			return 0;
		}
		if(DP[i][j]!=-1)
			return DP[i][j];
		DP[i][j]=Integer.MAX_VALUE;
		for(int k=i;k<j;k++) {
			DP[i][j]=Math.min(DP[i][j],minMatrixCalc(p,i,k)+minMatrixCalc(p,k+1,j)+p[i-1]*p[k]*p[j]);
		}
		return DP[i][j];
	}//DP approach
	static int minMatrixCalc(int p[],int i,int j) {
		if(i==j) {
			return 0;
		}
		int min=Integer.MAX_VALUE;
		for(int k=i;k<j;k++) {
			int count=minMatrixCalc(p,i,k)+minMatrixCalc(p,k+1,j)+p[i-1]*p[k]*p[j];
			if(count<min)
				min=count;
		}
		return min;
	}
	static int fromLeft(int arr[],int n) {
		//int point;
		int sum=0;
		int pro=1;
		for(int i=1;i<n-1;i++)
		{
			pro=arr[0]*arr[i]*arr[i+1];
			sum=sum+pro;
		}
		return sum;	
	}
	static int fromRight(int arr[],int n) {
		int sum=0;
		int pro=1;
		for(int i=n-2;i>1;i--)
		{
			pro=arr[n-1]*arr[i]*arr[i-1];
			sum=sum+pro;
		}
		return sum;	
	}
	static int minOpr(int arr[]) {
		int fL=fromLeft(arr,arr.length);
		int rl=fromRight(arr,arr.length);
		return Math.min(fL, rl);
	}	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//int n=sc.nextInt();
		int arr[]= {10, 20, 30, 40, 30,10,30,20,10,20,20,10,20,30,40};
		/*for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}*/
		//System.out.println(minOpr(arr));
		int n=arr.length;
		DP=new long[n+1][n+1];
		for(long[] row:DP)
			Arrays.fill(row, -1);
		System.out.println(minMatrixCalc1(arr, 1, arr.length-1));
	}
	
}
