import java.util.HashMap;

public class MaxNonAdjSum {
	    static HashMap <BinaryNode,Integer> DP;
	    public static int CalcMax(BinaryNode root){
	        if(root==null){return 0;
	        }
	        if(DP.containsKey(root)){
	        return DP.get(root);
	        }
	        int incl = root.data;
	        if(root.left!=null){
	            incl += CalcMax(root.left.left);
	            incl += CalcMax(root.left.right);
	        }
	          if(root.right!=null){
	            incl += CalcMax(root.right.left);
	            incl += CalcMax(root.right.right);
	        }
	        int excl = CalcMax(root.left)+CalcMax(root.right);
	        DP.put(root,  Math.max(incl, excl));
	        return DP.get(root);
	    }
	    public static void main(String args[]) {
	                DP = new HashMap<>();
	                BinaryTree bt=new BinaryTree();
	        		bt.root=new BinaryNode(1);
	        		bt.root.left= new BinaryNode(2);
	                bt.root.right = new BinaryNode(3);
	                bt.root.left.left= new BinaryNode(9);
	                bt.root.left.right= new BinaryNode(3);
	                bt.root.right.left = new BinaryNode(4);
	                bt.root.right.right = new BinaryNode(3);
	                bt.root.left.right.right= new BinaryNode(5);
	                bt.root.left.right.left= new BinaryNode(88);
	                bt.root.left.left.left =  new BinaryNode(44);
	                bt.root.left.left.right = new BinaryNode(66);
	                //long start = System.nanoTime();
	                System.out.println(CalcMax(bt.root));
	             //   System.out.println(" Time taken "+(System.nanoTime()-start));
		}
	}



