import java.util.ArrayList;
//here in dp approach,whenever a result is calculated we store them in dp array and whenever we come across that same no in recursion of greater number
//example we calculated fibo(5),we store it in dp array and while calculating fibo(6) this fibo(5) and fibo(4) need to be calculated again
//so every calculated result can be stored so that they need not be recalculated again,so fib(6) would take fib(5) and fib(4) from the dp array which has calculated results of fib(5) and fib(4)
//this reduces the time complexity to a greater extent, this becomes O(n) now
import java.util.Scanner;
public class FiboRecurDP {
	static int fib[];
	static int fibonacci(int n){
		if(n<=1) {
			return n;
		}
		if(fib[n]!=0) {//means that fib[n] has some number stored that means it has a calculated result 
			return fib[n];//returning value of already calculated number
		}
		fib[n]=fibonacci(n-1)+fibonacci(n-2);//this is to calculated new one which is not there in dp array
		return fib[n];	
	}

	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int n=131;
		fib=new int[n+1];
		int ans=fibonacci(131);
		System.out.println(ans);
	}
}
