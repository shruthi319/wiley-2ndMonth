import java.util.Collections;

public class BstMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	BinarySearchTree bst1=new BinarySearchTree();
	bst1.insert(70);
	bst1.insert(60);
	bst1.insert(80);
	bst1.insert(50);
	bst1.insert(65);
	bst1.insert(75);
	bst1.insert(85);
	/*System.out.println(bst1.root.data);
	System.out.println(bst1.root.left.data);
	System.out.println(bst1.root.right.data);
	System.out.println(bst1.root.left.left.data);
	System.out.println(bst1.root.left.right.data);
	System.out.println(bst1.root.right.left.data);
	System.out.println(bst1.root.right.right.data);*/
	bst1.inorder(bst1.root);
	System.out.println();
	bst1.preorder(bst1.root);
	System.out.println();
	bst1.postorder(bst1.root);
	System.out.println();
	bst1.levelOrder();
	}
}
