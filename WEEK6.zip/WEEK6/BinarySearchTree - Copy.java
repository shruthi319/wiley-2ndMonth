import java.util.LinkedList;
import java.util.Queue;

public class BinarySearchTree {
	BinaryNode root;
	public BinarySearchTree() {
		root=null;
	}
	private BinaryNode insertRec(BinaryNode currNode,int data) {
		if(currNode==null) {
			currNode=new BinaryNode(data);
			return currNode;
		}
		if(data<=currNode.data) {
			currNode.left=insertRec(currNode.left,data);
		}else if(data>currNode.data) {
			currNode.right=insertRec(currNode.right,data);
		}
		return currNode;
	}
	void insert(int data)
	{
		root=insertRec(root,data);
	}	
	void inorder(BinaryNode currNode) {
		if(currNode==null) {
			return;
		}
		inorder(currNode.left);
		System.out.print(currNode.data+"->");
		inorder(currNode.right);
	}
	void preorder(BinaryNode currNode) {
		if(currNode==null)
			return;
		System.out.print(currNode.data+"->");
		preorder(currNode.left);
		preorder(currNode.right);
	}
	void postorder(BinaryNode currNode) {
		if(currNode==null)
			return;
		postorder(currNode.left);
		postorder(currNode.right);
		System.out.print(currNode.data+"->");
	}
	void levelOrder() {
		Queue<BinaryNode> que=new LinkedList<>();
		que.add(root);
		while(!que.isEmpty()) {
			BinaryNode currNode=que.remove();
			System.out.print(currNode.data+"->");
			if(currNode.left!=null) {
				que.add(currNode.left);
			}
			if(currNode.right!=null) {
				que.add(currNode.right);
			}
		}
	}
	//returns minimum node in the current subtree
	BinaryNode minNode(BinaryNode currNode) {
		if(currNode.left==null)
			return currNode;
		return minNode(currNode.left);
	}
	
}
